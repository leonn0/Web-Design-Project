# Web Design and Development - Projekti

## Informacione të Përgjithshme
- **Departamenti:** Shkenca Kompjuterike / Dizajn Grafik
- **Lënda:** Web Design and Development
- **Profesori:** Mentor Qorri

## Struktura e Projektit

Projekti përmban këto fajlla:
- `index.html` - Faqja kryesore (Ballina)
- `about.html` - Faqja "Rreth Nesh"
- `contact.html` - Faqja e kontaktit
- `styles.css` - Stilizimi i të gjithë website-it
- `script.js` - Funksionaliteti JavaScript
- `README.md` - Ky fajll

## Si të Hapni Projektin

1. Ekstraktoni fajllin .zip
2. Hapni fajllin `index.html` në një shfletues (Chrome, Firefox, Edge, etj.)
3. Navigoni nëpër faqet duke përdorur menu-në

## Karakteristikat e Implementuara

### ✅ Kërkesat Kryesore
- [x] Të paktën 3 faqe të ndërlidhura (index.html, about.html, contact.html)
- [x] Navigim funksional mes faqeve
- [x] Të gjithë butonat janë funksionalë
- [x] Responsive design (Desktop, Tablet, Mobile)
- [x] Strukturë moderne dhe e organizuar
- [x] Fokus në përdorshmëri dhe estetikë

### 🎨 Elementët e Dizajnit
- Ngjyra moderne dhe paletë e harmonizuar
- Ikonografi intuitive
- Animacione të lehta (hover effects, transitions)
- Layout i pastër dhe i qartë
- Tipografi e lexueshme

### 📱 Responsive Design
Projekti funksionon perfekt në:
- Desktop (1200px+)
- Tablet (768px - 1199px)
- Mobile (deri në 767px)

### ⚡ Funksionalitetet JavaScript
- Menu responsive për mobile
- Validim i formës së kontaktit
- Animacione smooth scroll
- Mesazh suksesi pas dërgimit të formës
- Animacione on scroll

## Teknologjitë e Përdorura
- HTML5
- CSS3 (me CSS Variables dhe Flexbox/Grid)
- JavaScript (Vanilla JS - pa libraries)

## Shënim
Projekti është zhvilluar duke respektuar të gjitha kërkesat e specifikuara në udhëzimet e projektit.
